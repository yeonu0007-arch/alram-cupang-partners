import { VercelRequest, VercelResponse } from '@vercel/node';
import crypto from 'crypto';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const ACCESS_KEY = process.env.COUPANG_ACCESS_KEY;
  const SECRET_KEY = process.env.COUPANG_SECRET_KEY;

  if (!ACCESS_KEY || !SECRET_KEY) {
    console.error('[Coupang API] Missing API Keys in environment variables');
    return res.status(500).json({ 
      error: 'API keys not configured',
      debug: 'Please add COUPANG_ACCESS_KEY and COUPANG_SECRET_KEY to Vercel Environment Variables.'
    });
  }

  const DOMAIN = 'https://api-gateway.coupang.com';
  const URL = '/v2/providers/openapi/apis/api/v1/reports/realtime/summary'; // Performance summary
  const METHOD = 'GET';

  // Coupang expects date in GMT format: yyMMddTHHmmssZ
  const dateGMT = new Date().toISOString().replace(/[:\-]|\.\d{3}/g, '');
  
  const path = URL;
  const query = ''; // No query params for this endpoint usually
  const message = dateGMT + METHOD + path + query;

  const signature = crypto
    .createHmac('sha256', SECRET_KEY)
    .update(message)
    .digest('hex');

  const authorization = `CEA algorithm=HmacSHA256, access-key=${ACCESS_KEY}, signed-date=${dateGMT}, signature=${signature}`;

  console.log(`[Coupang API Debug] Requesting ${METHOD} ${URL}`);
  console.log(`[Coupang API Debug] Date: ${dateGMT}`);

  try {
    const response = await fetch(`${DOMAIN}${URL}`, {
      method: METHOD,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authorization
      }
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('[Coupang API Error]', data);
      return res.status(response.status).json({
        error: 'Coupang API Error',
        details: data,
        debug: {
          status: response.status,
          dateSent: dateGMT,
          pathRequested: URL
        }
      });
    }

    // Success - Data from Coupang
    return res.status(200).json({
      success: true,
      data: data.data, // Coupang usually returns { "rCode": "0", "rMessage": "SUCCESS", "data": [...] }
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('[Coupang API] Fetch failed:', error);
    return res.status(500).json({ 
      error: 'Fetch failed', 
      details: error instanceof Error ? error.message : String(error) 
    });
  }
}
