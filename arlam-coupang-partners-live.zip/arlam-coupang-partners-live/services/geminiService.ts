
import { GoogleGenAI, Type } from "@google/genai";
import { PartnerStats } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getPerformanceInsights(stats: PartnerStats): Promise<any> {
  const prompt = `Analyze these Coupang Partners performance statistics and provide professional insights in Korean.
  Stats: Clicks: ${stats.clicks}, Orders: ${stats.orders}, Commission: ${stats.commission} KRW, Conversion Rate: ${stats.conversionRate}%.
  
  Provide a JSON response with the following structure:
  {
    "title": "Short title",
    "description": "Analysis of current performance",
    "suggestion": "Actionable strategy to improve",
    "sentiment": "positive" | "neutral" | "negative"
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            suggestion: { type: Type.STRING },
            sentiment: { type: Type.STRING }
          },
          required: ["title", "description", "suggestion", "sentiment"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return {
      title: "분석 중 오류 발생",
      description: "통계를 분석하는 동안 문제가 발생했습니다.",
      suggestion: "잠시 후 다시 시도해주세요.",
      sentiment: "neutral"
    };
  }
}
